composition.py is the Brute force approach, can't solve #4 within reasonable time
compositionAStar.py is a more efficient A* Graph Traversal algorithm to help it find the solution quicker, can solve the problem #4 very quickly (average of 4 seconds), but worst case can take 8 minutes and 1GB of memory
